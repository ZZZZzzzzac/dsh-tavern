# DSH 人物卡格式与舞台声明

本文记录当前接口事实；不把讨论中的新协议字段当成可用能力。遇到工具或导入器明确报告的版本限制，以运行时结果为准。

## 版本分层

| 位置 | 含义 | 当前建卡规则 |
| --- | --- | --- |
| card.json 的 spec / spec_version | 通用人物卡格式 | 新建优先 chara_card_v3 / "3.0"；修改旧卡保留可支持的格式，迁移时同时转换数据结构 |
| data.character_version | 作者作品版本 | 作者自行维护的字符串，与格式、酒馆发行版本分别记录 |
| dsh.json 的 format / formatVersion | .dshcard 卡包格式 | 普通导入器当前接受 format: "dshcard"、formatVersion: 1；不要套用内部模组 archive v2 Schema |
| extensions.dsh_tavern.schemaVersion | DSH 卡片扩展结构 | 当前为整数 1；不使用酒馆版本号 3.2 替代 |
| 素材包 manifest.json 的 schemaVersion / contentHash | 素材结构与内容指纹 | 由素材库导出与校验，保持文件和清单一致 |

另有 `dsh-tavern-card-bundle` 卡包，结构与 `.dshcard` 的 `dsh.json` 不同，当前对应 schemaVersion 1。采用宿主提供的导出结果，不混用两种清单。

`dsh.json.card.version` 是包内作品版本。导出时与人物卡作品版本保持一致。格式升级必须匹配真实结构；仅修改版本数字不构成迁移。旧 `requires.tavernApi` 不能单独证明新舞台接口兼容。

## 规范声明位置

对 v2/v3 原始人物卡，使用 `/data/extensions/dsh_tavern`；无 data 包装的旧格式使用 `/extensions/dsh_tavern`。先读取原始格式再选择 JSON Pointer。酒馆资源文件内部的 raw 包装不属于作者卡片格式。

完整舞台的扩展示例：

```json
{
  "schemaVersion": 1,
  "assetBindings": {
    "boundPackIds": ["0f5613a4-ae7a-40e2-ba4a-17b4e7e9ce42"]
  },
  "stage": {
    "enabled": true
  }
}
```

这是扩展对象示例；UUID 必须替换为用户实际安装、可使用的素材包 ID，不照抄示例制造空绑定。

| 声明 | 有效模式 |
| --- | --- |
| stage.enabled: true | 舞台，自动开启气泡前置能力 |
| stage.enabled: false | 普通游玩，覆盖残留的旧开关 |
| enabled 缺省且没有旧字段 | 跟随玩家的全局开关（全局默认关，即普通游玩） |

**新卡只使用 `stage.enabled` 一个开关。** 它必须是布尔值。有素材、皮肤、openings、widgets、@bubble 或 galgame 插件，均不能替代此声明。

旧卡未写 enabled 时保留原语义：dialogue:true 开气泡，dialogue:true 与 stage:true 同时存在才开完整舞台。旧的气泡专用卡仍能运行；新 enabled 字段一旦存在就优先于旧字段。界面保存本卡开关时写 enabled 并移除两个旧字段；只有「气泡开、舞台关」这一组合仍写成 dialogue:true、stage:false；改选「全局…」时三个字段都移除，跟随全局。

`.dshcard` 导入器仍接受 `dsh.json.defaults.stage: true` 快捷声明，将其转换为 enabled:true。新增卡优先显式填写卡片字段。不能只看发行版本号就保证旧版酒馆认识这个字段；遇到旧运行时应要求更新，或按用户明确要求另做旧格式兼容副本。

stage.defaultSkin 是这张卡唯一的皮肤值「使用皮肤」：随卡导出导入，玩家在舞台 CONFIG › 画面「本卡皮肤」里改的也是它。没有填写或皮肤不可用时依次用全局「默认皮肤」和「经典」；素材包不再声明默认皮肤，旧的 stage.skinChoice 不再读取。stage.defaultEntrance 是本卡的「入场演出」（`{packId, kind:'entrances', assetId}`，缺省即不播放），只在玩家进入舞台时代替「载入中」播放，不替代舞台声明。模组的本卡设置由模组工具管理（stage-mods），不手写进卡。玩家密钥、静音和权限不能由卡包覆盖。

## 素材与迁移

绑定不等于安装成功。检查主包是否存在、角色是否可解析、头像是否存在、开场引用是否能解析。缺包时不要通过替换为不相关全局素材来宣称原卡已恢复。

内容文件、manifest.files 与 contentHash 必须由同一份最终内容生成。修改人物、清单或媒体后重新经素材库导出。哈希失败时保留原包并报告，不跳过检查或手改指纹来宣称兼容。

旧插件的 registerStageView 已停用。将展示数据迁入卡片声明、开场配置与素材包；旧插件里的整页界面（状态、地图等）改写成卡页面（`stage-status-panel`）；独立剧情逻辑再按公开插件接口处理。只删除旧调用、重命名插件或降低格式版本都不构成完整迁移。

## 封面与交付格式

统一交付 `.dshcard`，文件内容为 ZIP 卡包。封面保存在包内，由 `card.json` 的 `data.assets` 中 `type: "icon"`、`name: "main"` 的条目引用，素材 URI 使用 `embeded://` 包内路径。导入后在人物卡库展示封面；加密时封面与其他内容一起加密。

使用宿主支持的导出流程，保持 `dsh.json.formatVersion`、清单和实际文件一致。交付前重新导入卡包，检查封面、素材和插件。

## 卡包与验收

`.dshcard` 是卡包，至少区分 card.json 与 dsh.json；有素材和插件时清单路径与实际目录一一对应。优先使用宿主导出，保留授权和署名资料。作品名和插件包名分别处理，避免新卡继续沿用无关样例的插件身份。

交付状态分别报告：

1. 人物卡：字段、格式与扩展通过静态校验。
2. 素材：包已安装且引用可解析；失败说明包名和错误码。
3. 导出：真实文件存在且可重新读取；只有工具实际生成的下载信息才能提供给用户。
4. 试玩：仅实际运行后报告，包括开局正文、角色头像、舞台进入退出和声音停止。未试玩写明未验证。

舞台模块可用、卡片声明舞台、资源就绪与用户正在展示舞台，是四种不同状态。普通卡不运行本卡舞台任务；舞台卡可能在普通聊天视图准备导演数据，不承诺“没打开舞台就绝无模型调用”。未知协议版本和素材失败的完整降级能力仍需运行时验证，不能作为已实现承诺写给用户。
